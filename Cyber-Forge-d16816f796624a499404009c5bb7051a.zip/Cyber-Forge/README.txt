Cyber Forge

Open index.html in a browser to view the blue design, server animation,
courses, and practice tools. Automatic meeting emails require hosting.

The worker/ folder contains the server code. Run node worker/build.mjs
from this folder's parent to build the Cloudflare Worker at dist/server/index.js.
The included .openai/hosting.json identifies the original Codex Site.

To enable email delivery, configure MAILGUN_DOMAIN and MAILGUN_FROM and store
a domain sending key as the MAILGUN_API_KEY secret in the hosting environment.
Set MAILGUN_REGION to eu or au for domains outside Mailgun's US region.
