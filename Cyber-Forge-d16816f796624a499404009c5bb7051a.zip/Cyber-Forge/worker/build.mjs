import {mkdir, readFile, writeFile} from "node:fs/promises";

const project = new URL("../", import.meta.url);
const read = path => readFile(new URL(path, project), "utf8");
const write = (path, value) => writeFile(new URL(path, project), value);
const [source, page, manifest] = await Promise.all([
  read("worker/meeting.mjs"), read("index.html"), read(".openai/hosting.json")
]);
const routes = `
const pageHtml = ${JSON.stringify(page)};

export default {
  async fetch(request, env) {
    const {pathname} = new URL(request.url);
    if (pathname === "/api/meeting") return meetingRequest(request, env);
    if (pathname === "/" || pathname === "/index.html") {
      if (request.method !== "GET" && request.method !== "HEAD") {
        return new Response("Method not allowed", {status: 405, headers: {Allow: "GET, HEAD"}});
      }
      return new Response(request.method === "HEAD" ? null : pageHtml, {
        headers: {"Content-Type": "text/html; charset=UTF-8", "X-Content-Type-Options": "nosniff"}
      });
    }
    return new Response("Not found", {status: 404});
  },
};
`;
await Promise.all([
  mkdir(new URL("dist/server/", project), {recursive: true}),
  mkdir(new URL("dist/.openai/", project), {recursive: true})
]);
await Promise.all([
  write("dist/server/index.js", source + routes),
  write("dist/.openai/hosting.json", manifest)
]);
