const recipient = "warethmajeed@gmail.com";
const regions = {us: "api.mailgun.net", eu: "api.eu.mailgun.net", au: "api.au.mailgun.net"};
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const emailPattern = /^[^\s@<>(),;:"\\]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
const pending = new Map();

function json(data, status = 200, headers = {}) {
  return Response.json(data, {status, headers: {"Cache-Control": "no-store", ...headers}});
}

function error(message, status, headers) {
  return json({ok: false, message}, status, headers);
}

function providerConfig(env) {
  const domain = env.MAILGUN_DOMAIN?.trim();
  const from = env.MAILGUN_FROM?.trim();
  const region = env.MAILGUN_REGION?.trim().toLowerCase() || "us";
  const key = env.MAILGUN_API_KEY?.trim();
  if (!domain || !/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(domain) || !from || !emailPattern.test(from) || !key || !Object.hasOwn(regions, region)) return null;
  return {endpoint: `https://${regions[region]}/v3/${domain}/messages`, from, key};
}

async function readPayload(request) {
  const reader = request.body?.getReader();
  if (!reader) return null;
  const decoder = new TextDecoder();
  let body = "";
  let bytes = 0;
  for (;;) {
    const {done, value} = await reader.read();
    if (done) return JSON.parse(body + decoder.decode());
    bytes += value.byteLength;
    if (bytes > 8192) {
      await reader.cancel();
      return null;
    }
    body += decoder.decode(value, {stream: true});
  }
}

function validate(data) {
  if (!data || typeof data !== "object") return null;
  const clean = key => typeof data[key] === "string" ? data[key].trim() : "";
  const name = clean("name");
  const email = clean("email");
  const day = clean("day");
  const time = clean("time");
  const topic = clean("topic");
  const id = clean("requestId");
  if (!uuid.test(id) || !name || name.length > 80 || /[\u0000-\u001f]/.test(name)
    || email.length > 254 || !emailPattern.test(email) || topic.length > 500
    || !/^\d{4}-\d{2}-\d{2}$/.test(day) || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)) return null;
  const [year, month, date] = day.split("-").map(Number);
  const calendar = new Date(Date.UTC(year, month - 1, date));
  if (calendar.toISOString().slice(0, 10) !== day || new Date(`${day}T${time}:00+03:00`).getTime() <= Date.now()) return null;
  return {name, email, day, time, topic, id, spam: Boolean(clean("company"))};
}

async function cacheKey(origin, prefix, secret, value) {
  const text = new TextEncoder().encode(`${secret}\n${prefix}\n${value}`);
  const bytes = new Uint8Array(await crypto.subtle.digest("SHA-256", text));
  const digest = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  return new Request(`${origin}/api/meeting/state/${prefix}/${digest}`);
}

async function sendMeeting(config, meeting) {
  const fields = new FormData();
  fields.set("from", `Cyber Forge <${config.from}>`);
  fields.set("to", recipient);
  fields.set("subject", `Cyber Forge meeting request · ${meeting.day} ${meeting.time}`);
  fields.set("h:Reply-To", meeting.email);
  fields.set("o:tracking", "no");
  fields.set("text", [
    "A Cyber Forge learner requested a meeting.",
    "",
    `Name: ${meeting.name}`,
    `Reply email: ${meeting.email}`,
    `Requested day and time: ${meeting.day}, ${meeting.time} Bahrain time (UTC+3)`,
    meeting.topic && `What they want help with: ${meeting.topic}`,
    "",
    "Reply to the learner to confirm a time."
  ].filter(line => line !== false).join("\n"));
  const response = await fetch(config.endpoint, {
    method: "POST",
    redirect: "error",
    headers: {Authorization: `Basic ${btoa(`api:${config.key}`)}`},
    body: fields,
    signal: AbortSignal.timeout(8500),
  });
  const data = await response.json().catch(() => ({}));
  return response.ok && typeof data.id === "string" && data.id.length > 0;
}

export async function meetingRequest(request, env) {
  const {origin} = new URL(request.url);
  if (request.method === "GET") return json({available: Boolean(providerConfig(env))});
  if (request.method !== "POST") return error("Use the meeting form to send a request.", 405, {Allow: "GET, POST"});
  if (request.headers.get("Origin") !== origin) return error("Open the meeting form on Cyber Forge.", 403);
  if (!/^application\/json(?:;|$)/i.test(request.headers.get("Content-Type") || "")) return error("Use the meeting form to send a request.", 415);
  const config = providerConfig(env);
  if (!config) return error("Meeting emails are being set up. Please try again later.", 503);

  const data = await readPayload(request).catch(() => null);
  const meeting = validate(data);
  if (!meeting) return error("Check your name, email address, and requested time.", 422);
  if (meeting.spam) return error("Your request could not be sent.", 422);

  const cache = caches.default;
  const sender = request.headers.get("CF-Connecting-IP") || meeting.email.toLowerCase();
  const [idKey, senderKey] = await Promise.all([
    cacheKey(origin, "request", config.key, `${meeting.id}:${meeting.email}`),
    cacheKey(origin, "sender", config.key, sender)
  ]);
  const requests = pending.get(senderKey.url);
  if (requests?.id === idKey.url) return (await requests.result).clone();
  if (requests || pending.size >= 64) return error("Another request is being sent. Try again shortly.", 429);

  const result = (async () => {
    try {
      const previous = await cache.match(idKey);
      if (previous) return json({ok: true});
      if (await cache.match(senderKey)) return error("Please wait a minute before sending another request.", 429, {"Retry-After": "60"});
      await cache.put(senderKey, new Response("1", {headers: {"Cache-Control": "public, max-age=60"}}));
      if (!await sendMeeting(config, meeting)) return error("Your request could not be sent. Please try again later.", 502);
      // Retain only a hashed request receipt so an ordinary retry does not resend the email.
      await cache.put(idKey, new Response("1", {headers: {"Cache-Control": "public, max-age=86400"}})).catch(() => {});
      return json({ok: true}, 202);
    } catch {
      return error("We couldn’t confirm delivery. Please wait before trying again.", 502);
    }
  })();
  pending.set(senderKey.url, {id: idKey.url, result});
  try {
    return (await result).clone();
  } finally {
    pending.delete(senderKey.url);
  }
}
